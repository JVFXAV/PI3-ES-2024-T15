package com.example.projetointegrador3

import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.ExifInterface
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.projetointegrador3.R.id.dialog_imageview
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.picasso.Callback
import com.squareup.picasso.Picasso
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class LeituraNFCActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvNomeUsuario: TextView
    private lateinit var tvCelularUsuario: TextView
    private lateinit var tvOpcao: TextView
    private lateinit var layoutImages: LinearLayout
    private lateinit var btnEncerrarLocacao: Button

    private var nfcAdapter: NfcAdapter? = null
    private var loadingDialog: AlertDialog? = null
    private var locacaoId: String? = null
    private var numeroArmarioDisponivel: String? = null
    private var dataHoraInicio: Date? = null
    private var dataHoraFim: Date? = null
    private var dataHoraFimPrevisto: Date? = null
    private var totalAPagar: Double? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leitura_nfc)

        tvStatus = findViewById(R.id.tvStatus)
        tvNomeUsuario = findViewById(R.id.tvNomeUsuario)
        tvCelularUsuario = findViewById(R.id.tvCelularUsuario)
        tvOpcao = findViewById(R.id.tvOpcao)
        layoutImages = findViewById(R.id.layoutImages)
        btnEncerrarLocacao = findViewById(R.id.btnEncerrarLocacao)

        locacaoId = intent.getStringExtra("locacaoId")
        if (locacaoId != null) {
            buscarDadosLocacao(locacaoId!!)
        } else {
            Toast.makeText(this, "ID da locação não encontrado", Toast.LENGTH_SHORT).show()
        }

        btnEncerrarLocacao.setOnClickListener {
            showConfirmationDialog()
        }

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
    }

    override fun onResume() {
        super.onResume()
        val pendingIntent: PendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT
        )
        val nfcIntentFilter = arrayOf(
            IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED),
            IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED),
            IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED)
        )
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, nfcIntentFilter, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)

        val tag: Tag? = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
        if (tag != null) {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                cleanNfcTag(ndef)
            } else {
                Toast.makeText(this, "Tag NFC não suporta NDEF", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showConfirmationDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Encerrar Locação")
        builder.setMessage("Tem certeza de que deseja encerrar a locação? Isso adicionará uma data de término e calculará o valor a ser pago.")
        builder.setPositiveButton("Sim") { _, _ ->
            showLoadingDialog()
        }
        builder.setNegativeButton("Não", null)
        builder.show()
    }

    private fun showLoadingDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Aproxime a pulseira NFC")
        builder.setMessage("Esperando pela aproximação da tag NFC... A tag será limpa e a locação encerrada.")
        builder.setCancelable(false)
        loadingDialog = builder.create()
        loadingDialog?.show()
    }

    private fun cleanNfcTag(ndef: Ndef) {
        try {
            ndef.connect()
            val emptyNdefRecord = NdefRecord.createTextRecord(null, "")
            val emptyNdefMessage = NdefMessage(emptyNdefRecord)
            ndef.writeNdefMessage(emptyNdefMessage)
            ndef.close()

            // Encerrar locação no Firestore
            encerrarLocacao()

            loadingDialog?.dismiss()
            Toast.makeText(this, "Tag NFC limpa e locação encerrada com sucesso", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            loadingDialog?.dismiss()
            Toast.makeText(this, "Falha ao limpar a tag NFC: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun encerrarLocacao() {
        val db = FirebaseFirestore.getInstance()
        dataHoraFim = Date()
        locacaoId?.let {
            db.collection("locacoes").document(it).get().addOnSuccessListener { document ->
                if (document.exists()) {
                    dataHoraInicio = document.getDate("dataHoraInicio")
                    dataHoraFimPrevisto = document.getDate("dataHoraFimPrevisto")
                    val opcao = document.getString("opcao")
                    val numeroArmario = document.getString("numeroArmario")
                    val unidadeId = document.getString("unidadeId")

                    if (dataHoraInicio != null && opcao != null && numeroArmario != null && unidadeId != null) {
                        calcularTotalAPagar(unidadeId, dataHoraInicio!!, dataHoraFim!!, opcao) { total ->
                            totalAPagar = total

                            val updates = hashMapOf(
                                "dataHoraFim" to dataHoraFim,
                                "totalAPagar" to totalAPagar,
                                "status" to "encerrado"
                            )

                            db.collection("locacoes").document(it).update(updates as Map<String, Any>)
                                .addOnSuccessListener {
                                    Toast.makeText(this, "Locação encerrada com sucesso", Toast.LENGTH_SHORT).show()
                                    atualizarStatusArmario(unidadeId, numeroArmario)
                                    mostrarResumoLocacao(dataHoraInicio!!, dataHoraFimPrevisto!!, dataHoraFim!!, totalAPagar!!)
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(this, "Erro ao encerrar locação: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                        }
                    } else {
                        Toast.makeText(this, "Erro: dados da locação estão incompletos", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Locação não encontrada", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun atualizarStatusArmario(unidadeId: String, numeroArmario: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("unidades").whereEqualTo("id", unidadeId).get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val document = documents.documents.first()
                    val docId = document.id
                    db.collection("unidades").document(docId)
                        .update("armarios.$numeroArmario.status", "disponivel")
                        .addOnSuccessListener {
                            Toast.makeText(this, "Status do armário atualizado com sucesso", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(this, "Erro ao atualizar status do armário: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao buscar unidade: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun calcularTotalAPagar(unidadeId: String, dataHoraInicio: Date, dataHoraFim: Date, opcao: String, callback: (Double) -> Unit) {
        val db = FirebaseFirestore.getInstance()
        db.collection("unidades").whereEqualTo("id", unidadeId).get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val document = documents.documents.first()
                    val opcoesLocacao = document.get("opcoesLocacao") as Map<String, Number>
                    val diff = dataHoraFim.time - dataHoraInicio.time
                    val diffMinutes = diff / (1000 * 60)

                    val totalAPagar = when {
                        diffMinutes <= 30 -> (opcoesLocacao["30min"]?.toDouble()) ?: 0.0
                        diffMinutes <= 60 -> (opcoesLocacao["1h"]?.toDouble()) ?: 0.0
                        diffMinutes <= 120 -> (opcoesLocacao["2h"]?.toDouble()) ?: 0.0
                        else -> (opcoesLocacao["dia"]?.toDouble()) ?: 0.0
                    }

                    callback(totalAPagar)
                } else {
                    Toast.makeText(this, "Erro ao buscar preços da unidade", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao buscar preços da unidade: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun mostrarResumoLocacao(dataHoraInicio: Date, dataHoraFimPrevisto: Date, dataHoraFim: Date, totalAPagar: Double) {
        val builder = AlertDialog.Builder(this)
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

        builder.setTitle("Resumo da Locação")
        builder.setMessage("""
            Horário de Início: ${sdf.format(dataHoraInicio)}
            Horário Previsto para Término: ${sdf.format(dataHoraFimPrevisto)}
            Horário de Término: ${sdf.format(dataHoraFim)}
            Total a Pagar: R$ $totalAPagar
        """.trimIndent())
        builder.setPositiveButton("Retornar") { _, _ ->
            finish()
        }
        builder.show()
    }

    private fun buscarDadosLocacao(locacaoId: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("locacoes").document(locacaoId).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val uid = document.getString("uid")
                    val opcao = document.getString("opcao")
                    val fotosUrls = document.get("fotosUrls") as List<String>
                    numeroArmarioDisponivel = document.getString("numeroArmario")

                    tvOpcao.text = "Opção Escolhida: $opcao"
                    mostrarFotos(fotosUrls)
                    uid?.let { buscarDadosUsuario(it) }
                } else {
                    tvStatus.text = "Locação não encontrada"
                }
            }
            .addOnFailureListener { e ->
                tvStatus.text = "Erro ao buscar locação: ${e.message}"
            }
    }

    private fun buscarDadosUsuario(uid: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("pessoas").document(uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    tvNomeUsuario.text = document.getString("nome")
                    tvCelularUsuario.text = document.getString("celular")
                } else {
                    tvNomeUsuario.text = "Usuário não encontrado"
                }
            }
            .addOnFailureListener { e ->
                tvNomeUsuario.text = "Erro ao buscar usuário: ${e.message}"
            }
    }

    private fun mostrarFotos(fotosUrls: List<String>) {
        layoutImages.removeAllViews()
        for (url in fotosUrls) {
            val imageView = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    200.dpToPx(this@LeituraNFCActivity), // Convert dp to px
                    200.dpToPx(this@LeituraNFCActivity)
                ).apply {
                    setMargins(5.dpToPx(this@LeituraNFCActivity), 0, 5.dpToPx(this@LeituraNFCActivity), 0)
                }
                scaleType = ImageView.ScaleType.CENTER_CROP
                setOnClickListener {
                    showImageDialog(url)
                }
                Picasso.get().load(url).into(this, object : Callback {
                    override fun onSuccess() {
                        // Corrige a orientação da imagem
                        correctImageOrientation(this@apply, url)
                    }
                    override fun onError(e: Exception?) {
                        Toast.makeText(this@LeituraNFCActivity, "Erro ao carregar imagem", Toast.LENGTH_SHORT).show()
                    }
                })
            }
            layoutImages.addView(imageView)
        }
    }

    private fun correctImageOrientation(imageView: ImageView, imageUrl: String) {
        try {
            val uri = Uri.parse(imageUrl)
            val inputStream = contentResolver.openInputStream(uri)
            val exif = inputStream?.let { ExifInterface(it) }
            val orientation = exif?.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED)

            val rotation = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
            imageView.rotation = rotation.toFloat()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun showImageDialog(imageUrl: String) {
        val dialogBuilder = AlertDialog.Builder(this)
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_image, null)
        dialogBuilder.setView(dialogView)

        val imageView = dialogView.findViewById<ImageView>(dialog_imageview)
        Picasso.get().load(imageUrl).into(imageView)

        dialogBuilder.setPositiveButton("Fechar") { dialog, _ -> dialog.dismiss() }
        dialogBuilder.create().show()
    }

    private fun Int.dpToPx(context: Context): Int = (this * context.resources.displayMetrics.density + 0.5f).toInt()
}
