package com.example.projetointegrador3

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.FirebaseFirestore

class GerenteOptionsActivity : AppCompatActivity() {

    private lateinit var btnLiberarLocacao: Button
    private lateinit var btnLerNFC: Button
    private lateinit var logout: ImageButton
    private lateinit var nomeTextView: TextView
    private lateinit var infosGerenteTextView: TextView
    private val firestore = FirebaseFirestore.getInstance()

    companion object {
        private const val CAMERA_REQUEST_CODE = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gerente_options)

        btnLiberarLocacao = findViewById(R.id.btnLiberarLocacao)
        btnLerNFC = findViewById(R.id.btnLerNFC)
        logout = findViewById(R.id.logout_button)
        nomeTextView = findViewById(R.id.nome_text_view)
        infosGerenteTextView = findViewById(R.id.tvinfosGerente)

        val unidadeId = intent.getStringExtra("unidadeId")

        if (unidadeId != null) {
            carregarInformacoesGerente(unidadeId)
        }

        btnLiberarLocacao.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST_CODE)
            } else {
                if (unidadeId != null) {
                    startCameraActivity(unidadeId)
                }else {
                    Toast.makeText(this, "UnidadeId não encontrada", Toast.LENGTH_LONG).show()
                }
            }
        }

        btnLerNFC.setOnClickListener {
        }

        logout.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                val unidadeId = intent.getStringExtra("unidadeId")
                if (unidadeId != null) {
                    startCameraActivity(unidadeId)
                }else {
                    Toast.makeText(this, "UnidadeId não encontrada", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startCameraActivity(unidadeId: String) {
        val intent = Intent(this, CameraQrActivity::class.java)
        intent.putExtra("unidadeId", unidadeId)
        startActivity(intent)
    }

    private fun carregarInformacoesGerente(unidadeId: String) {
        firestore.collection("unidades")
            .whereEqualTo("id", unidadeId)
            .get()
            .addOnSuccessListener { documents ->
                if (documents != null && !documents.isEmpty) {
                    val unidade = documents.firstOrNull()
                    unidade?.let {
                        nomeTextView.text = "Olá, " + it.getString("gerente")
                        infosGerenteTextView.text = """
                            Sua Unidade: 
                            ${it.getString("nome")}
                            ${it.getString("endereco")}
                        """.trimIndent()
                    }
                } else {
                    nomeTextView.text = "Dados não encontrados"
                    infosGerenteTextView.text = "Não foi possível carregar informações"
                }
            }
            .addOnFailureListener { e ->
                nomeTextView.text = "Erro ao carregar"
                infosGerenteTextView.text = "Erro: ${e.message}"
            }
    }
}
