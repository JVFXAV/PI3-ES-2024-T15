package com.example.projetointegrador3

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ViewCardActivity : AppCompatActivity() {

    private lateinit var numCartaoTextView: TextView
    private lateinit var nomeCartaoTextView: TextView
    private lateinit var validadeCartaoTextView: TextView
    private lateinit var excluirCartaoButton: Button
    private lateinit var adicionarNovoCartaoButton: Button
    private lateinit var voltarButton: ImageButton

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_card_viewer)

        // Inicialização de componentes de interface do usuário
        numCartaoTextView = findViewById(R.id.numero_cartao_text_view)
        nomeCartaoTextView = findViewById(R.id.nome_titular_text_view)
        validadeCartaoTextView = findViewById(R.id.validade_text_view)
        excluirCartaoButton = findViewById(R.id.excluir_cartao_button)
        adicionarNovoCartaoButton = findViewById(R.id.adicionar_novo_cartao_button)
        voltarButton = findViewById(R.id.back_button)

        firebaseAuth = FirebaseAuth.getInstance()
        val userId = firebaseAuth.currentUser?.uid

        // Verifica se o usuário está autenticado e obtém os dados do cartão do Firestore
        if (userId != null) {
            val firestore = FirebaseFirestore.getInstance()
            val cartaoRef = firestore.collection("pessoas").document(userId)
            cartaoRef.get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val cartaoCredito = document.get("cartaoCredito") as? Map<*, *>
                        if (cartaoCredito != null) {
                            val numero = cartaoCredito["numeroCartao"] as? String
                            val nomeTitular = cartaoCredito["nomeTitular"] as? String
                            val dataExpiracao = cartaoCredito["dataExpiracao"] as? String
                            numCartaoTextView.text = "Número Cartão: ${numero}"
                            nomeCartaoTextView.text = "Nome do Titular: ${nomeTitular}"
                            validadeCartaoTextView.text = "Validade: ${dataExpiracao}"
                        } else {
                            // Log de aviso se os dados do cartão de crédito não forem encontrados
                            Log.d("ViewCardActivity", "Dados do cartão de crédito não encontrados")
                        }
                    } else {
                        // Log de aviso se o documento do usuário não for encontrado
                        Log.d("ViewCardActivity", "Documento do usuário não encontrado")
                    }
                }
                .addOnFailureListener { exception ->
                    // Log de erro ao recuperar os dados do cartão
                    Log.d("ViewCardActivity", "Erro ao recuperar dados do cartão", exception)
                    // Exibição de mensagem de erro para o usuário
                    Toast.makeText(this@ViewCardActivity, "Erro ao recuperar dados do cartão", Toast.LENGTH_SHORT).show()
                }
        }

        // Configuração do botão para excluir o cartão
        excluirCartaoButton.setOnClickListener {
            // Implementação para excluir o cartão do banco de dados
        }

        // Configuração do botão para adicionar um novo cartão
        adicionarNovoCartaoButton.setOnClickListener {
            val intent = Intent(this@ViewCardActivity, CardActivity::class.java)
            startActivity(intent)
        }

        // Configuração do botão para voltar à tela inicial
        voltarButton.setOnClickListener {
            val intent = Intent(this@ViewCardActivity, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
