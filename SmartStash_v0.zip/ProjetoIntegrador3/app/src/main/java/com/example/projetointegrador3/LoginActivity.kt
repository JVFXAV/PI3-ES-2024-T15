package com.example.projetointegrador3

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException

class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: TextInputEditText
    private lateinit var senhaEditText: TextInputEditText
    private lateinit var loginButton: Button
    private lateinit var recuperarSenhaButton: Button
    private lateinit var gotoCadastroButton: Button
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Inicialização do Firebase Auth
        firebaseAuth = FirebaseAuth.getInstance()

        // Inicialização dos componentes de interface do usuário
        emailEditText = findViewById(R.id.email_edit_text)
        senhaEditText = findViewById(R.id.senha_edit_text)
        loginButton = findViewById(R.id.login_button)
        recuperarSenhaButton = findViewById(R.id.recuperarSenha_button)
        gotoCadastroButton = findViewById(R.id.cadastro_button)

        // Configuração do botão de login
        loginButton.setOnClickListener {
            // Verificar se todos os campos estão preenchidos
            if (camposEstaoPreenchidos()) {
                // Alterar o texto do botão para indicar o carregamento
                loginButton.text = "Carregando..."
                loginCliente()
            } else {
                Toast.makeText(this@LoginActivity, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }

        // Configuração do botão para ir para a tela de cadastro
        gotoCadastroButton.setOnClickListener {
            val intent = Intent(this@LoginActivity, CadastroActivity::class.java)
            startActivity(intent)
        }

        // Configuração do botão para ir para a tela de recuperação de senha
        recuperarSenhaButton.setOnClickListener {
            val intent = Intent(this@LoginActivity, RecuperarSenhaActivity::class.java)
            startActivity(intent)
        }
    }

    // Verifica se todos os campos necessários estão preenchidos
    private fun camposEstaoPreenchidos(): Boolean {
        return emailEditText.text!!.isNotBlank() &&
                senhaEditText.text!!.isNotBlank()
    }

    // Método para realizar o login do cliente
    private fun loginCliente() {
        val email = emailEditText.text.toString().trim()
        val senha = senhaEditText.text.toString()

        firebaseAuth.signInWithEmailAndPassword(email, senha)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Se o login for bem-sucedido, redireciona para a tela inicial
                    val user = firebaseAuth.currentUser
                    if (user != null) {
                        val userEmail = user.email
                        val userId = user.uid
                        Toast.makeText(applicationContext, "Usuário autenticado: $userEmail $userId", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@LoginActivity, HomeActivity::class.java)
                        startActivity(intent)
                    }
                } else {
                    // Se houver falha no login, trata os possíveis erros
                    try {
                        throw task.exception!!
                    } catch (invalidEmail: FirebaseAuthInvalidUserException) {
                        // Se o usuário não for encontrado
                        Toast.makeText(applicationContext, "Usuário não encontrado", Toast.LENGTH_SHORT).show()
                    } catch (invalidPassword: FirebaseAuthInvalidCredentialsException) {
                        // Se as credenciais forem inválidas
                        Toast.makeText(applicationContext, "Credenciais inválidas", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        // Outros erros durante o processo de login
                        Log.e("LoginActivity", "Erro ao fazer login: ${e.message}")
                        Toast.makeText(applicationContext, "Erro ao fazer login", Toast.LENGTH_SHORT).show()
                    }
                }
            }
    }
}
