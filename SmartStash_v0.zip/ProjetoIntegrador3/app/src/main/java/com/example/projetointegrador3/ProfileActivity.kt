package com.example.projetointegrador3

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileActivity : AppCompatActivity() {

    private lateinit var nomeTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var cpfTextView: TextView
    private lateinit var celTextView: TextView
    private lateinit var dtNascTextView: TextView
    private lateinit var backButton: ImageButton
    private lateinit var editProfileButton: Button

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Inicialização dos componentes de interface do usuário
        nomeTextView = findViewById(R.id.name_text_view)
        emailTextView = findViewById(R.id.email_text_view)
        cpfTextView = findViewById(R.id.cpf_text_view)
        celTextView = findViewById(R.id.cel_text_view)
        dtNascTextView = findViewById(R.id.dtNasc_text_view)
        backButton = findViewById(R.id.back_button)
        editProfileButton = findViewById(R.id.edit_profile_button)

        firebaseAuth = FirebaseAuth.getInstance()

        val currentUser = firebaseAuth.currentUser
        if (currentUser != null) {
            val userId = currentUser.uid
            val userEmail = currentUser.email

            // Busca os dados do usuário no Firestore usando o UID
            val firestore = FirebaseFirestore.getInstance()
            val userRef = firestore.collection("pessoas").document(userId)
            userRef.get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val user = document.toObject(User::class.java)
                        // Define os dados do usuário nos componentes de interface do usuário
                        nomeTextView.text = user?.nome ?: "Nome não encontrado"
                        emailTextView.text = userEmail
                        cpfTextView.text = user?.cpf ?: "CPF não encontrado"
                        celTextView.text = user?.celular ?: "Celular não encontrado"
                        dtNascTextView.text = user?.dataNascimento ?: "Data de Nascimento não encontrada"
                    } else {
                        Log.d("ProfileActivity", "Documento não encontrado")
                    }
                }
                .addOnFailureListener { exception ->
                    Log.d("ProfileActivity", "get failed with ", exception)
                }
        } else {
            // Exibe mensagem se nenhum usuário estiver logado
            Toast.makeText(applicationContext, "Nenhum usuário logado", Toast.LENGTH_SHORT).show()
        }

        // Configuração do botão para editar o perfil do usuário
        editProfileButton.setOnClickListener {
        }

        // Configuração do botão para voltar à tela inicial
        backButton.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    // Classe de dados para representar o usuário
    data class User(
        val nome: String? = null,
        val email: String? = null,
        val cpf: String? = null,
        val celular: String? = null,
        val dataNascimento: String? = null
    )
}
