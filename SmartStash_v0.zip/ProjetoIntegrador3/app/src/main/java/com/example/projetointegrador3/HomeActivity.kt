package com.example.projetointegrador3

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HomeActivity : AppCompatActivity() {

    private lateinit var nomeTextView: TextView
    private lateinit var logoutButton: ImageButton
    private lateinit var profileButton: ImageButton
    private lateinit var cadastrarCartaoButton: FloatingActionButton

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homepage)

        // Inicialização dos componentes de interface do usuário
        nomeTextView = findViewById(R.id.nome_text_view)
        logoutButton = findViewById(R.id.logout_button)
        profileButton = findViewById(R.id.visualizar_perfil_button)
        cadastrarCartaoButton = findViewById(R.id.adicionar_cartao_fab)

        // Inicialização do Firebase Auth
        firebaseAuth = FirebaseAuth.getInstance()

        // Obtendo o usuário atualmente autenticado
        val currentUser = firebaseAuth.currentUser
        if (currentUser != null) {
            val userId = currentUser.uid

            // Buscando o nome do usuário no Firestore usando o UID
            val firestore = FirebaseFirestore.getInstance()
            val userRef = firestore.collection("pessoas").document(userId)
            userRef.get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val user = document.toObject(User::class.java)
                        nomeTextView.text = "Olá, ${user?.nome}"
                    } else {
                        Log.d("HomeActivity", "Documento não encontrado")
                    }
                }
                .addOnFailureListener { exception ->
                    Log.d("HomeActivity", "Falha ", exception)
                }
        } else {
            // Se nenhum usuário estiver autenticado, exibir mensagem
            Toast.makeText(applicationContext, "Nenhum usuário logado", Toast.LENGTH_SHORT).show()
        }

        // Configurando o botão de logout
        logoutButton.setOnClickListener {
            realizarLogout()
        }

        // Configurando o botão para visualizar o perfil do usuário
        profileButton.setOnClickListener{
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        // Configurando o botão para adicionar cartão
        cadastrarCartaoButton.setOnClickListener {
            val intent = Intent(this, ViewCardActivity::class.java)
            startActivity(intent)
        }
    }

    // Estrutura de dados para representar um usuário
    data class User(
        val nome: String? = null,
        val email: String? = null
    )

    // Método para realizar logout do usuário
    private fun realizarLogout() {
        firebaseAuth.signOut()
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}
