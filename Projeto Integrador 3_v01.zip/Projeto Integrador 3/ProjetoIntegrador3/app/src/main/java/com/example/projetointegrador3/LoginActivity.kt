package com.example.projetointegrador3

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException

class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: TextInputEditText
    private lateinit var senhaEditText: TextInputEditText
    private lateinit var loginButton: Button
    private lateinit var recuperarSenhaButton: Button
    private lateinit var gotoCadastroButton: Button
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var gotoMapButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        firebaseAuth = FirebaseAuth.getInstance()

        emailEditText = findViewById(R.id.email_edit_text)
        senhaEditText = findViewById(R.id.senha_edit_text)
        loginButton = findViewById(R.id.login_button)
        recuperarSenhaButton = findViewById(R.id.recuperarSenha_button)
        gotoCadastroButton = findViewById(R.id.cadastro_button)
        gotoMapButton = findViewById(R.id.mapa_button) as ImageButton

        // Recuperar o e-mail do SharedPreferences e mostrar diálogo
        val prefs = getSharedPreferences("PreferenciasDoApp", MODE_PRIVATE)
        val emailSalvo = prefs.getString("emailUsuario", null)
        if (!emailSalvo.isNullOrEmpty()) {
            mostrarDialogoEmail(emailSalvo)
        }

        loginButton.setOnClickListener {
            if (camposEstaoPreenchidos()) {
                loginButton.text = "Carregando..."
                loginCliente()
            } else {
                Toast.makeText(this@LoginActivity, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }

        gotoCadastroButton.setOnClickListener {
            val intent = Intent(this@LoginActivity, CadastroActivity::class.java)
            startActivity(intent)
        }

        recuperarSenhaButton.setOnClickListener {
            val intent = Intent(this@LoginActivity, RecuperarSenhaActivity::class.java)
            startActivity(intent)
        }

        gotoMapButton.setOnClickListener {
            val intent = Intent(this@LoginActivity, MapActivity::class.java)
            startActivity(intent)
        }
    }

    private fun camposEstaoPreenchidos(): Boolean {
        return emailEditText.text!!.isNotBlank() && senhaEditText.text!!.isNotBlank()
    }

    private fun loginCliente() {
        val email = emailEditText.text.toString().trim()
        val senha = senhaEditText.text.toString()

        firebaseAuth.signInWithEmailAndPassword(email, senha)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Salvar o e-mail no SharedPreferences
                    val prefs = getSharedPreferences("PreferenciasDoApp", MODE_PRIVATE)
                    prefs.edit().apply {
                        putString("emailUsuario", email)
                        apply()
                    }

                    val user = firebaseAuth.currentUser
                    if (user != null) {
                        Toast.makeText(applicationContext, "Usuário logado: ${user.email}", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@LoginActivity, HomeActivity::class.java)
                        startActivity(intent)
                    }
                } else {
                    try {
                        throw task.exception!!
                    } catch (invalidEmail: FirebaseAuthInvalidUserException) {
                        Toast.makeText(applicationContext, "Usuário não encontrado", Toast.LENGTH_SHORT).show()
                    } catch (invalidPassword: FirebaseAuthInvalidCredentialsException) {
                        Toast.makeText(applicationContext, "Credenciais inválidas", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Log.e("LoginActivity", "Erro ao fazer login: ${e.message}")
                        Toast.makeText(applicationContext, "Erro ao fazer login", Toast.LENGTH_SHORT).show()
                    }
                }
            }
    }

    private fun mostrarDialogoEmail(email: String) {
        AlertDialog.Builder(this).apply {
            setTitle("E-mail salvo")
            setMessage("Utilizar $email para fazer login?")
            setPositiveButton("Sim") { _, _ ->
                emailEditText.setText(email)
            }
            setNegativeButton("Não") { dialog, _ ->
                dialog.dismiss()
            }
            show()
        }
    }
}
